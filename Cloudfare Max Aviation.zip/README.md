# Flight Progress Board

Dispatch board, scheduling and reporting for a flight training unit.

## Putting it online — Cloudflare Pages

No build step, no command line needed.

1. Sign in at **dash.cloudflare.com** → **Workers & Pages** → **Create** → **Pages** → **Upload assets**.
2. Name the project, then drag in `index.html` and `_headers`. Press **Deploy site**.
3. It's live at `https://<project>.pages.dev` within a few seconds.

To update it later, open the project → **Create new deployment** → drag the new `index.html` in.

### Put a password on it

This is the main reason to prefer Cloudflare. A `pages.dev` site is public by default, but Cloudflare Access can require a login before anyone sees it, free for up to 50 people:

1. **Zero Trust** → **Access** → **Applications** → **Add an application** → **Self-hosted**.
2. Point it at your `pages.dev` domain.
3. Add a policy: *Allow* → *Emails* (list your staff) or *Email domain* (your school's domain).

Staff then sign in with a one-time code sent to their email. Nobody else reaches the board at all.

That is still not the same as real per-user permissions inside the app — everyone who gets in has full staff access — but it does keep the site off the open internet, which matters if there are real student names in it.

### Your own domain

Project → **Custom domains** → **Set up a domain**. If the domain is already on Cloudflare it takes about a minute; otherwise you'll be asked to point its nameservers at Cloudflare first.

### If you'd rather deploy from Git

Connect the repository instead of uploading, and set **Build command:** *(leave empty)*, **Build output directory:** `/`. Every push then redeploys automatically.

## Putting it online — GitHub Pages

1. Create a repository on GitHub — call it whatever you like.
2. Upload **`index.html`** to the top level of it. That's the only file that matters.
3. Go to **Settings → Pages**.
4. Under *Source*, choose **Deploy from a branch**, pick `main` and `/ (root)`, and press Save.
5. Wait a minute or two. Your board appears at
   `https://<your-username>.github.io/<repository-name>/`

To change anything later, edit `index.html` in the repository and the site updates itself within a minute.

If you'd rather not use the command line at all, GitHub's web interface handles the whole thing: **Add file → Upload files**, drag `index.html` in, and press *Commit changes*.

Note that GitHub Pages has no equivalent of Cloudflare Access on the free tier — the site is public to anyone with the link.

## Files

| File | What it's for |
|---|---|
| `index.html` | The whole application. This is the only file that has to be uploaded. |
| `_headers` | Security headers, read by Cloudflare Pages. Ignored by GitHub Pages. |
| `README.md` | This. |
| `flight-schedule-dashboard.jsx` | The source, for when you build it properly. |
| `flight-scheduler-technical-spec.md` | The database, permissions and build plan for a real version. |

## Before you rely on it

**Nothing is saved.** Every booking, student and roster lives in the browser tab. Reload the page and it returns to the seeded example data. This is a working prototype of the interface, not a system of record — treat it as something to show people and try workflows in, not somewhere to keep real bookings.

**Anyone with the link can see it.** GitHub Pages sites are public. Don't put real student names in it while it's hosted this way.

**The Staff / Student switch is a preview, not security.** It hides controls; it doesn't enforce anything. A curious student could re-enable them.

Making it a real system means adding a database, logins and permissions enforced on a server. That's what `flight-scheduler-technical-spec.md` describes.

## What it does

- **Schedule** — one column per aircraft or per staff member, drag to move, click to book, sign aircraft out and in
- **Fuel** — tank balancing and uplift in gallons and litres
- **Instructors** — rosters, working hours, time off
- **Staff** — shift rostering with a generator that respects rest rules
- **Students** — progress, availability, booking history, cancellation record
- **Progress reports** — who is moving and who has stalled
- **CFI** — completed flying by month against daylight capacity, cancellations by reason, breakdowns by aircraft and instructor
- **Setup** — fleet, booking types, syllabus, staff and roles, and the metrics the CFI page reports on
- **Export** — the whole dataset as an Excel workbook, nine sheets

## Notes on how it runs

The page compiles itself in the browser using Babel, and loads React, Tailwind and SheetJS from CDNs. That keeps it to a single file you can upload anywhere, at the cost of a second or two on first load and a dependency on those CDNs being reachable.

For a real deployment you'd build it properly — the source is `flight-schedule-dashboard.jsx`, and any Vite React project will take it as-is.

## Airfield

Set your own field under **Setup → Aircraft & simulators → Airfield**. Latitude and longitude drive the sunrise, sunset and twilight lines and the CFI daylight capacity model. It ships set to CYLW (Kelowna).
